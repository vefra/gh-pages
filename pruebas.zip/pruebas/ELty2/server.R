library(shiny);#require(scales)

### Parte donde se procesa la data
options(shiny.maxRequestSize=30*1024^2)

shinyServer(function(input, output,session) {
  

  ### Carga de la data
  
  Data1 <- reactive({
    inFile <- input$file1
    if (is.null(inFile))
      return(NULL)
    df.raw <- read.table(inFile$datapath, header=T, sep="\t", stringsAsFactors = F)
    df.raw <- tratbase(df.raw)
    
    return(df.raw)
  })
  
  
  ##### segmentacion ###
  
  output$segm <- renderUI({
    d <- Data1()
    x<- c("Todos",sort(unique(d[,"SEGMENTO"])))
    selectInput('segm', 'Escoja un segmento',
                choices = x,selected = "Todos")
  })
  
  output$segm2 <- renderUI({
    d <- Data1()
    x<- c("Todos",sort(unique(d[,"SEGMENTO"])))
    selectInput('segm2', 'Escoja un segmento',
                choices = x,selected = "Todos")
  })
  
  output$segm3 <- renderUI({
    d <- Data1()
    x<- c("Todos",sort(unique(d[,"SEGMENTO"])))
    selectInput('segm3', 'Escoja un segmento para PD',
                choices = x,selected = "Todos")
  })
  
  
  
  # Pestana 1 calculo de la base de TR
  
  bas<-reactive({
    
    if(!input$baseTR){
      TRb_1<-TRb_T2
      finalDF1<- finalDF2
    } else {
      TRb_1<-TRb_T
      finalDF1<- finalDF
    }
    
    if(is.null(input$segm)){
          DF<-TRb_1
    }
    else if(input$segm=="Todos"){
    
        DF<-TRb_1
    
    }else{
    base<-Data1()
    
    TRba<-tasas2(base,finalDF1)
    DF<-TRba[TRba$Segmentos==input$segm,]
    
    }
    
    return(DF)
    })
  
  values <- reactiveValues()
 
  observeEvent(!is.null(input$segm),{
    values$DF<- bas()
     })
  
  ## Handsontable
  observe({
  
    if (!is.null(input$hot)) {
      values[["previous"]] <- isolate(values[["DF"]])
      DF = hot_to_r(input$hot)
    } else {
      if (is.null(values[["DF"]]))
        DF <- DF ##TRba[TRba==input$segm,]
      else
        DF <- values[["DF"]]
    }
    values[["DF"]] <- DF##TRba[TRba==input$segm,]
  })
  
  output$hot <- renderRHandsontable({
    DF <- values[["DF"]]
    if (!is.null(DF))
      rhandsontable(DF, stretchH = "all")
  })
  
  ## Save 
  observeEvent(input$save, {
    #  fileType <- isolate(input$fileType)
    
    x<-input$segm
    
    y<-paste("baseTR",x,".Rdata",sep="")
    
    finalDF <- isolate(values[["DF"]])
    save(finalDF,file=y)
    
  }
  )
  
  
  recupera <- reactive({
    
    base.pe.f<- Data1()
    
    if(input$segm=="Todos"){
      basesub <- base.pe.f[ (base.pe.f$score >= input$minscore &
                                base.pe.f$score <= input$maxscore) &
                             (base.pe.f$ndven_n >= input$mindias &
                                base.pe.f$ndven_n <= input$maxdias),]
    }else {
    basesub <- base.pe.f[base.pe.f$Segmentos == input$segm &
                           (base.pe.f$score >= input$minscore &
                              base.pe.f$score <= input$maxscore) &
                           (base.pe.f$ndven_n >= input$mindias &
                              base.pe.f$ndven_n <= input$maxdias),]
    }
    
    
    if(input$mindias ==0 ){
      
      evsald <- data.frame (colSums(basesub[,c("SALDO_DEUDA_N0" ,
                                               "Saldo_Mora_N1"  ,
                                               "Saldo_Mora_N2" ,
                                               "Saldo_Mora_N3" ,
                                               "Saldo_Mora_N4" ,
                                               "Saldo_Mora_N5" ,
                                               "Saldo_Mora_N6" ,
                                               "Saldo_Mora_N7" ,
                                               "Saldo_Mora_N8" ,
                                               "Saldo_Mora_N9" ,
                                               "Saldo_Mora_N10",
                                               "Saldo_Mora_N11",
                                               "Saldo_Mora_N12")],na.rm = T))
    } else {
      evsald <- data.frame (colSums(basesub[basesub$marcaven==1,c("Saldo_Mora_N0" ,
                                                                  "Saldo_Mora_N1"  ,
                                                                  "Saldo_Mora_N2" ,
                                                                  "Saldo_Mora_N3" ,
                                                                  "Saldo_Mora_N4" ,
                                                                  "Saldo_Mora_N5" ,
                                                                  "Saldo_Mora_N6" ,
                                                                  "Saldo_Mora_N7" ,
                                                                  "Saldo_Mora_N8" ,
                                                                  "Saldo_Mora_N9" ,
                                                                  "Saldo_Mora_N10",
                                                                  "Saldo_Mora_N11",
                                                                  "Saldo_Mora_N12")],na.rm = T))
    }
    
    names(evsald) <- c("Suma")
    
    evsald$Saldos<- row.names(evsald)
    
    evsald<- evsald[,c("Saldos","Suma")]
    
    evsald<-recup(evsald,input$n)
    
    return(evsald)
  })
  
  
  output$evsaldos <-  renderTable({
    
    evsald<-recupera()
    
    evsald <- format(evsald,digits=6)
    return(evsald)
    
    
  })
  
  
  output$summsald <- renderPrint({
    
    if (!input$summary) {return(cat("
                                    ¡La información de resumen de datos esta oculta!"))}
    else {
      dataset<-recupera()
      
      return(summary(dataset[dataset[,3]>0,c(3,4)]))
      
    }
    
    })
  
  ## Pestana 2 calculo de la TR  ###
  
  datos2<-reactive({
    
    TR <- values[["DF"]]
    
    tr_no_venc <- cbind(TR[,1:4])
    TR <- TR[,-c(1:4)]
    TR
    
    d_ven <- seq(1.1,1.5,0.1)
    r_score <- seq(-2.7,2.7, by=0.6)
    
    k1 <- input$k1
    k2 <- input$k2
    k3 <- input$k3
    
    f_log_log <- function(x,y){
      v <- (1/(1+exp(x-k1)))*(exp(-y+k2))+k3
      return(v)
    }
    
    TR_M <- matrix(c(0), nrow= length(r_score), ncol=length(d_ven))
    for(i in seq(1:nrow(TR_M))){
      for(j in seq(1:ncol(TR_M))){
        TR_M[i,j]<- f_log_log(r_score[i],d_ven[j])
      }
    }
    #TR_M
    #plot(TR_M[,1])
    #plot(TR_M[1,])
    
    ## FUNCION LLENAR MATRIZ
    trasl <- as.numeric(TR[10,]/TR_M[10,])
    TR <-  matrix(c(0), nrow= nrow(TR_M), ncol=ncol(TR_M))
    for (j in seq (1:ncol(TR_M))){
      TR[,j] <- trasl[j] * TR_M[,j]
    }
    #TR
    k4<-input$k4
    TR_compl <- cbind(tr_no_venc,TR)
    TR_compl<-as.data.frame(TR_compl)
    TR_compl$NoVencido <- TR_compl$NoVencido-k4
    names(TR_compl)<-c("Score_min","Score_max","PD","No Vencido","1 a 30 dias","31 a 60 dias","61 a 90 dias",
                       "90 a 120 dias","mas de 120 dias")
    TR_compl$Segmentos <- input$segm
    TR_compl$Rango_Score<-10:1
    return(TR_compl)
  })
  
  
  ## Save TR 
  observeEvent(input$save2, {
    #  fileType <- isolate(input$fileType)
    
    x<-input$segm
    
    y<-paste("TR",x,".Rdata",sep="")
    
    TR <- datos2()
    save(TR,file=y)
    
  }
  )
  
  
  output$TRtabla <- renderDataTable({
    
    TR_compl<-datos2()
    # names(TR_compl)<-c("No Vencido","1 a 30 días","31 a 60 días","61 a 90 días",
    #                             "90 a 120 días","mas de 120 días")
    TR_compl<-format(TR_compl,digits = 6)
    
    return(TR_compl)
    
    
  },
  options=list(
    paging = FALSE,
    searching=F
  ))
  
  
  
  val_sb <- reactiveValues()
  
  ## Handsontable
  observe({
    if (!is.null(input$porcen)) {
      #if(input$picture=="SB"){
      val_sb[["previous"]] <- isolate(val_sb[["por_prov"]])
      #} else{
      #  val_sb[["previous"]] <- isolate(val_sb[["por_prov_seps"]])
      #}
      por_prov = hot_to_r(input$hot)
    } else {
      if(input$picture=="SB"){
        if (is.null(val_sb[["por_prov"]]))
          por_prov <- por_prov_sb
        else
          por_prov <- val_sb[["por_prov"]]
      }else{
        if (is.null(val_sb[["por_prov"]]))
          por_prov <- por_prov_seps
        else
          por_prov <- val_sb[["por_prov"]]
        
      }
    }
    
    val_sb[["por_prov"]] <- por_prov
  })
  
  output$porcen <- renderRHandsontable({
    por_prov <- val_sb[["por_prov"]]
    if (!is.null(por_prov))
      rhandsontable(por_prov, stretchH = "all")
  })
  
  
  rv <- reactiveValues()
  rv$data <- NULL
  
  observe({    ## will 'observe' the button press
    
    if(input$calcular){ 
      base.pe.f<-Data1()
      print("here")  ## for debugging
      rv$data <- tasas(unique(base.pe.f$Segmentos))   ## store the data in the reactive value
      rv$data 
    }
  })
  
  
  baseped<-reactive({
    base.pe.f<-Data1()
    x<-unique(as.character(base.pe.f$Segmentos))
    
    TR<-rv$data
      TR$Rango_Score_l<- paste("Puntaje de ",TR$Score_min," a ",TR$Score_max)
      
      TR1 <- melt(TR, id=c("Rango_Score","Rango_Score_l","PD","Segmentos","Score_min","Score_max"))
      names(TR1)<-c("Rango_Score","Rango_Score_l", "PD","Segmentos","Score_min","Score_max","Rango_Dias","TR")
      TR1$Dias_mora<-ifelse(TR1$Rango_Dias=="No Vencido",1,2)
      TR1$Dias_mora<-ifelse(TR1$Rango_Dias=="31 a 60 dias",3,TR1$Dias_mora)
      TR1$Dias_mora<-ifelse(TR1$Rango_Dias=="61 a 90 dias",4,TR1$Dias_mora)
      TR1$Dias_mora<-ifelse(TR1$Rango_Dias=="90 a 120 dias",5,TR1$Dias_mora)
      TR1$Dias_mora<-ifelse(TR1$Rango_Dias=="mas de 120 dias",6,TR1$Dias_mora)
      
      TR1$LGD<- round(1- (TR1$TR/100),digits=6)
      
      BDD<- base.pe.f[base.pe.f$pobval>0,]
    
      a<-list()
      for(i in unique(BDD$Segmentos)){
        a[[i]]<-BDD[BDD$Segmentos==i,c("COD_ID_SUJETO","Segmentos","score","FechaCorte")]
        a[[i]]$Rango_Score<-cut(a[[i]]$score,c(unique(TR1[TR1$Segmentos==i,]$Score_max),0),labels=(1:10))
      }
      rscores<-rbindlist(a)
      rm(a)
      BDD<-merge(BDD,rscores,by=c("COD_ID_SUJETO","Segmentos","score","FechaCorte"))
      rm(rscores)
      gc()
      
      BDD<- merge(BDD,TR1,by=c("Rango_Score","Dias_mora","Segmentos"))
      
    if(input$picture=="SB"){
      BDD<- merge(BDD,por_prov_sb,by="calif")
      BDD$Prov_Max <- round(BDD$EXPO*BDD$por_prov_max,2)
      BDD$Prov_Min <- round(BDD$EXPO*BDD$por_prov_min,2)
    } else {
      BDD<- merge(BDD,por_prov_seps,by="calif")
      BDD$Prov_Max <- round(BDD$EXPO*BDD$por_prov_max,2)
      BDD$Prov_Min <- round(BDD$EXPO*BDD$por_prov_min,2)
    }
    
      BDD$PE <- round(BDD$EXPO*BDD$PD*BDD$LGD,2)
    
    
    return(BDD)
    
  })    
  
  
  output$downloadData <- downloadHandler(
    
    filename = function() {
     file= paste("Base_PE_com", ".csv", sep = "")
    }
    ,
    content = function(file) {
      write.table(baseped(), file, row.names = FALSE,na="",sep=",",dec=".",quote=F)
    }
  )
  
  output$basepe <- renderDataTable({
    
    BDD<-baseped()
    
    resum<- aggregate(cbind(EXPO,PE,Prov_Min,Prov_Max) ~ Segmentos,BDD,sum,na.rm = T)
    
    resum <- rbind(resum, data.frame(Segmentos='Total',EXPO=sum(resum$EXPO), PE = sum(resum$PE) ,
                                     Prov_Min = sum(resum$Prov_Min),Prov_Max = sum(resum$Prov_Max)))
    
    resum$porPE<-round(abs(resum$Prov_Min-resum$PE)/resum$Prov_Min,1)
    
    names(resum)<-c("Segmentos","Exposicion","Perdida Esperada","Minimo","Maximo","% PE vs Min")
    
    datatable(resum, filter="none", options = list(dom = 't'), rownames= FALSE) %>%
      formatCurrency(c("Exposicion","Perdida Esperada","Minimo","Maximo"), "$") %>%
    formatPercentage('% PE vs Min', 2)
    
  },
  options=list(
    paging = FALSE,
    searching=F))
  
  #})
  
  output$pescore <- DT::renderDataTable({
    
    BDD<-baseped()
    
    if(input$segm2 =="Todos"){
      BDD<-BDD
      BDD$Rango_Score_T <- bin(BDD$score,nbins=10,method = "content")
        
      bmin<- aggregate(score ~ Rango_Score_T,BDD,min,na.rm = T)
      
      bmax<- aggregate(score ~ Rango_Score_T,BDD,max,na.rm = T)
      
      resum<- aggregate(cbind(EXPO,PE,Prov_Min,Prov_Max) ~ Rango_Score_T,BDD,sum,na.rm = T)
      
      resum$Rango_Score_T<- paste("Puntaje de ",bmin$score," a ",bmax$score)
      
      resum$porPE<-round(abs(resum$Prov_Min-resum$PE)/resum$Prov_Min,1)
      
      names(resum)<-c("Rango Score","Exposición","Perdida Esperada","Minimo","Maximo","% PE vs Min")
      
      datatable(resum,options = list(dom = 't'), rownames= FALSE)  %>%
        formatCurrency(c("Exposición","Perdida Esperada","Minimo","Maximo"), "$") %>%
        formatPercentage("% PE vs Min", 1)
      
    }
    else{
    BDD<-BDD[BDD$Segmentos== input$segm2,]
    resum<- aggregate(cbind(EXPO,PE,Prov_Min,Prov_Max) ~ Rango_Score_l,BDD,sum,na.rm = T)
    
    resum$porPE<-round(abs(resum$Prov_Min-resum$PE)/resum$Prov_Min,1)
    
    names(resum)<-c("Rango Score","Exposición","Perdida Esperada","Minimo","Maximo","% PE vs Min")
    
    datatable(resum,options = list(dom = 't'), rownames= FALSE)  %>%
      formatCurrency(c("Exposición","Perdida Esperada","Minimo","Maximo"), "$") %>%
      formatPercentage("% PE vs Min", 1)
    
    }
    
  },
  options=list(
    paging = FALSE,
    searching=F))
  
  output$expdias <- renderDataTable({
    
    BDD<-baseped()
    
    if(length(input$segm)==1){
      BDD<-BDD
    }else {
    BDD<-BDD[BDD$Segmentos== input$segm,]
    }
    resum<- aggregate( EXPO ~ Rango_Score + Rango_Dias,BDD,sum,na.rm = T)
    
    resum <- cast(resum, Rango_Score ~ Rango_Dias)
    
    return(resum)
    
    
  },
  options=list(
    paging = FALSE,
    searching=F))
  
  
  output$basetrf <- renderDataTable({
    
    TR<-rv$data
    
    datatable(TR,options = list(dom = 't', rownames= FALSE),filter = "top") %>%
    formatRound(c("1 a 30 dias","31 a 60 dias","61 a 90 dias","90 a 120 dias","mas de 120 dias"), digits = 4)
      #    formatStyle('SEGMENTO',
   #               backgroundColor = styleInterval(SEGMENTO, c('gray', 'yellow')))
    
  },
  options=list(
    paging = FALSE,
    searching=F))
  
  
  
  output$tabcast <- renderDataTable({
    BDD<-baseped()
    BDD$count<-1
    cast<- aggregate(cbind(count,EXPO) ~ marcast,BDD,sum,na.rm = T)
    
    x<-sum(cast$count,na.rm =T)
    y<- sum(cast$EXPO, na.rm =T)
    cast$porsuj<-round((cast$count/x)*100,2)
    cast$porexpo<-round((cast$EXPO/y)*100,2)
    
    cast<-cast[,c("marcast","count","porsuj","EXPO","porexpo")]
    cast<- rbind(cast,c("Total",x,100,y,100))
    names(cast)<-c("Marca","N","%N","Exposición","%Exposición")
    return(cast)
    
  },
  options=list(
    paging = FALSE,
    searching=F))
  
  
  output$tabseg <- renderDataTable({
    BDD<-baseped()
    BDD$count<-1
    cast<- aggregate(cbind(count,EXPO) ~ Segmentos,BDD,sum,na.rm = T)
    
    x<-sum(cast$count,na.rm =T)
    y<- sum(cast$EXPO, na.rm =T)
    cast$porsuj<-round((cast$count/x)*100,2)
    cast$porexpo<-round((cast$EXPO/y)*100,2)
    
    cast<-cast[,c("Segmentos","count","porsuj","EXPO","porexpo")]
    cast<- rbind(cast,c("Total",x,100,y,100))
    names(cast)<-c("Segmentos","N","%N","Exposición","%Exposición")
    return(cast)
    
  },
  options=list(
    paging = FALSE,
    searching=F))
  
  
  
  output$plot1 <- renderPlot({
    data<-datos2()
    
    plot(data[,1])
    
  })
  
  
  
  
  output$plot2 <- renderPlotly({
    
    BDD<-baseped()
    BDD$count<-1
    casti<-aggregate(count~marcast,BDD,sum)
    
    casti$pocast<-100*casti$count/sum(casti$count)
    
    plot_ly(casti) %>%
      add_trace(x = ~marcast, y = ~pocast, type = 'bar', color=~marcast,colors="Set2",
                #  marker = list(color = '#C9EFF9'),
                hoverinfo = "text",
                text = ~paste(round(pocast,2), ' %')) %>%
    layout(title = 'Población con castigo',
           xaxis = list(title = ""),
           yaxis = list(side = 'left', title = '', barmode='group',showgrid = FALSE, 
                        zeroline = FALSE))
    
  })
  
  
  output$plotseg <- renderPlotly({
    
    BDD<-baseped()
    BDD$count<-1
    casti<-aggregate(count~Segmentos,BDD,sum)
    
    casti$pocast<-100*casti$count/sum(casti$count)
    
    plot_ly(casti, labels = ~Segmentos, values = ~pocast, type = 'pie') %>%
      layout(title = 'Segmentos',
             xaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE),
             yaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE))
    
    
  })
  
  
  output$plotpe <- renderPlotly({
    
    BDD<-baseped()
    
    resum<- aggregate(cbind(PE,EXPO,Prov_Min,Prov_Max) ~ Segmentos,BDD,sum,na.rm = T)
    
    plot_ly(resum) %>%
      add_trace(x = ~Segmentos, y = ~PE, type = 'bar', name = 'PE',
                #  marker = list(color = '#C9EFF9'),
                hoverinfo = "text",
                text = ~paste(round(PE/1000000,2), ' M')) %>%
      add_trace(x = ~Segmentos, y = ~Prov_Min, type = 'bar', name = 'Min',
                #  marker = list(color = '#C9EFF9'),
                hoverinfo = "text",
                text = ~paste(round(Prov_Min/1000000,2), ' M')) %>%
      add_trace(x = ~Segmentos, y = ~Prov_Max, type = 'bar', name = 'Max',
                #  marker = list(color = '#C9EFF9'),
                hoverinfo = "text",
                text = ~paste(round(Prov_Max/1000000,2), ' M')) %>%
      add_trace(x = ~Segmentos, y = ~EXPO, type = 'scatter', mode = 'lines', 
                name = 'Expo', yaxis = 'y2',
                #  line = list(color = '#45171D'),
                hoverinfo = "text",
                text = ~paste(round(EXPO/1000000,0), ' M')) %>%
      layout(title = 'Distribución',#legend = list(x = 0.7, y = 0.9),
             xaxis = list(title = ""),
             yaxis = list(side = 'left', title = '', barmode='group',showgrid = FALSE, 
                          zeroline = FALSE),
             yaxis2 = list(side = 'right', overlaying = "y", title = 'Expo', 
                           showgrid = FALSE, zeroline = FALSE),
             margin = list(l = 50, r = 60, b = 50, t = 50, pad = 4),
             legend = list(orientation = 'h'))
  })
  
  output$image1 <- renderImage({
    
    return(list(
      src = "images/dias.jpg",
      contentType = "image/jpeg",
      alt = "Face"
    ))
    
  }, deleteFile = FALSE)
  
  
  output$image2 <- renderImage({
    if (is.null(input$picture))
      return(NULL)
    
    if (input$picture == "SB") {
      return(list(
        src = "images/SB.jpg",
        contentType = "image/jpeg",
        alt = "SB"
      ))
    } else if (input$picture == "SEPS") {
      return(list(
        src = "images/SEPS.jpg",
        filetype = "image/jpeg",
        alt = "SEPS"
      ))
    }
    
  }, deleteFile = FALSE)
  
  
  # output$PDgrp <- renderPlot({
  #   
  #   BDD<-baseped()
  #   
  #   if(input$segm3=="Todos"){
  #     BDD<-BDD
  #   } else{
  #     BDD<-BDD[BDD$SEGMENTO==input$segm3,]
  #   }
  #   
  #   ggplot(BDD, aes(x=Score_G, y=PD*100, group=factor(SEGMENTO))) +
  #     geom_line(aes(color=factor(SEGMENTO)),
  #               size=1)+
  #     scale_y_continuous(name = "Porcentaje",
  #                        breaks = seq(0, 100, 10),
  #                        limits=c(0, 100)) +
  #     scale_x_continuous(name = "Score",
  #                        breaks = seq(0, 1000, 100),
  #                        limits=c(150, 1000)) +
  #     ggtitle("Probabilidad default") +
  #     scale_color_brewer(palette="Dark2")
  #   
  # })
  
  
  output$PDgrp2 <- renderPlot({
    
    BDD<-baseped()
    
    if(input$segm3=="Todos"){
      BDD<-BDD
    } else{
      BDD<-BDD[BDD$Segmentos==input$segm3,]
    }
    
    ggplot(BDD, aes(x=Rango_Score, y=PD*100, group=factor(Segmentos))) +
      geom_line(aes(color=factor(Segmentos)),
                size=1)+
      ggtitle("Probabilidad default") +
      scale_color_brewer(palette="Dark2")
    
  })
  
  
  ################  REPORTING ##########################################
  
  Reponum<-reactive({
    BDD<-baseped()

    tipo.var  <- sapply(BDD,class)
    BDD.num <- BDD[,which(tipo.var=="numeric")]
#    BDD.cat <- BDD[,which(tipo.var!="numeric")]
    
  })
  
  output$varinum <- renderUI({
    d <- Reponum()
    x<- sort(names(d))
    selectInput('varinum', 'Escoja una variable cuantitativa',
                choices = x,"PE")
  })
  # outvarinum = reactive({
  #   d <- Reponum()
  #   sort(names(d))
  # })
  # observe({
  #   updateSelectInput(session, "varinum",
  #                     choices = outvarinum()
  #   )})
  
  Repochar<-reactive({
    BDD<-baseped()
    #BDD$COD_ID_SUJETO <- as.character(BDD$COD_ID_SUJETO)
    tipo.var  <- sapply(BDD,class)
    #BDD.num <- BDD[,which(tipo.var=="numeric")]
    BDD.cat <- BDD[,which(tipo.var!="numeric")]
    
  })
  
  output$varichar <- renderUI({
    d <- Repochar()
    x<- sort(names(d),decreasing = T)
    selectInput('varichar', 'Escoja una variable cualitativa',
                choices = x,"Segmentos")
  })
  # outvarichar = reactive({
  #   d <- Repochar()
  #   sort(names(d))
  # })
  # observe({
  #   updateSelectInput(session, "varichar",
  #                     choices = outvarichar()
  #   )})
  
  output$charplot <- renderPlotly({
    
    BDD<-baseped()
    
    vari<-input$varichar
    tip<-ifelse(input$tip==1,"group","stack")
    ori<-ifelse(input$ori==1,"v","h")
    
    base <- BDD[,c("COD_ID_SUJETO",vari,"Segmentos")]
      # 2018-04-13: Draw the segment where occurs the max separation
      
      names(base) <- c("ID","var","Segmentos")
      
      base$count<-1
      
      civil<- aggregate(count ~ Segmentos+var,base,sum,na.rm = T)
      civil$value<- 100*civil$count/sum(civil$count,na.rm = T)
      civil2<- aggregate(count ~ var,base,sum,na.rm = T)
      civil2$value<- 100*civil2$count/sum(civil2$count,na.rm = T)
      civil4<- aggregate(count ~ Segmentos,base,sum,na.rm = T)
      civil3<-merge(civil,civil4,by="Segmentos")
      civil3$value<-100*civil3$count.x/civil3$count.y
      civil2$Segmentos<-factor("Total")
      
      civil3<-civil3[order(civil3$value),]
      #civil3$Estado<- factor(1:length(unique(civil3$var)),labels=unique(civil3$var))
      civil2<-civil2[order(civil2$value),]
      civil2$Estado<- factor(1:length(civil2$var),labels=civil2$var)
      
      civil6<- merge(civil3,civil2[,c("var","Estado")],by="var")
      
      
      p1<- plot_ly(civil6, x = ~Segmentos, y = ~value, type = 'bar',orientation = ori, 
                   name = ~Estado, color = ~Estado, colors="Paired") %>%
        layout(yaxis = list(title = ''), barmode = tip
        )
      
      p2<-plot_ly(civil2, x=~Segmentos, y = ~value, type = "bar",orientation = ori,
                  color = ~Estado, colors="Paired") %>%
        layout( barmode = tip,legend = list(orientation = 'h'))
      
      p <- subplot( style(p1, showlegend = F),
                    style(p2, showlegend = T),shareY = T, widths = c(0.8, 0.2))
      
      p %>% layout ( title = "Poblacion")
    
    
#    p<-chart_barg(BDD[,c("COD_ID_SUJETO",input$varichar,"Segmentos")], input$variable,var ,ori)
    
#    p    
    
  })
  
  output$charbox <- renderPlotly({
    
    BDD<-baseped()
    
    vari<-input$varinum
    base<-BDD[,c("COD_ID_SUJETO",input$varinum,"Segmentos")]
      
      names(base) <- c("ID","var","Segmentos")
      base$var <-ifelse(base$var>as.numeric(quantile(base$var , 0.98,na.rm=T)),
                        as.numeric(quantile(base$var , 0.98,na.rm=T)),base$var)
      
      p1<-plot_ly(base, 
                  y = ~var, color = ~Segmentos,colors=brewer.pal(6, "Paired")
                  , type = "box") 
      
      p2<- plot_ly(base, y = ~var,  type = "box",name="Total")
      
      p <- subplot(p1, p2,shareY = T, widths = c(0.8, 0.2)) %>%
        layout(
          title = vari ,
          yaxis = list(
            title = vari,
            #   range = c(0,1000),
            zeroline = T)
        )
      #p <- p + geom_segment(aes(x = x, y = y), colour = grey(.6), size = 1.0)
      p
  
  })
  
  output$charpe <- renderPlotly({
    
    BDD<-baseped()
    
    vari<-input$varichar
    tip<-ifelse(input$tip==1,"group","stack")
    ori<-ifelse(input$ori==1,"v","h")
    
    base <- BDD[,c("COD_ID_SUJETO",vari,"PE")]
    # 2018-04-13: Draw the segment where occurs the max separation
    
    names(base) <- c("ID","var","PE")
    
    civil<- aggregate(PE ~ var,base,sum,na.rm = T)
    
    
    p1<- plot_ly(civil, x = ~var, y = ~PE, type = 'bar',orientation = ori
                 ) %>%
      layout(title = paste('PE vs',vari))
      
    
    p1
    
    
  })
  
  output$charpen <- renderPlotly({
    
    BDD<-baseped()
    
    vari<-input$varinum

    base <- BDD[,c("COD_ID_SUJETO",vari,"PE","Segmentos")]
    # 2018-04-13: Draw the segment where occurs the max separation
    
    names(base) <- c("ID","var","PE","Segmentos")
    
    p1<- plot_ly(base, x = ~var, y = ~PE, color = ~Segmentos, colors="Paired") %>%
      layout(title = paste('PE vs',vari))
      
      
    
    p1
    
    
  })
  ########################################################################
  # PRUEBA DESCARGA
  ########################################################################
  
  output$downloadReport <- downloadHandler(
    filename = function() {
      if(input$partitionCat == " - "){ 
        nombre = paste0(input$score,"_",input$response)
      }
      if(input$partitionCat !=" - "){ 
        nombre = paste0(input$score,"_",input$response,"_",input$partition,"_",input$partitionCat)
      }
      
      
      paste(nombre, sep = '.', switch(
        input$format, PDF = 'pdf', HTML = 'html', Word = 'docx'
      ))
    },
    
    content = function(file) {
      src <- normalizePath('report.Rmd')
      
      # temporarily switch to the temp dir, in case you do not have write
      # permission to the current working directory
      owd <- setwd(tempdir())
      on.exit(setwd(owd))
      file.copy(src, 'report.Rmd')
      
      out <- render('report.Rmd', switch(
        input$format,
        PDF = pdf_document(), HTML = html_document(), Word = word_document()
        #         PDF = knit2pdf(), HTML = html_document(), Word = word_document()
      ))
      file.rename(out, file)
    }
  )
  
  
  })

