##################################################
#### Global ######################################
### Cabcera Equipo analytics Autor version fecha ultimos cambios
##################################################
## Base prueba es el input y para la ejecucion 
#base.pe.f <- base_prueba
#posterios a correr comentar la linea

## Sabe descargar paquetes en R

###### 2 .- Carga de paquetes ###########

packages <- c('ggplot2','plotly','reshape2','reshape','plyr','shiny','rhandsontable',
              'data.table','DT','stringr','knitr','rmarkdown','OneR')

for (package in packages) {
  if (!(require(package, character.only=T, quietly=T))) {
    install.packages(package)
    library(package, character.only=T)
  }
}

rm(package,packages)

require(reshape)
library(rhandsontable)
library(shiny)
require(data.table)
require(reshape2)
require(DT)
require(plotly)
require(RColorBrewer)
require(OneR)
## Ingrese la base a trabajar #####

## Verificar que existan estas variables dentro de la base.
## "COD_ID_SUJETO","Segmentos","score","FechaCorte"

tratbase <- function(base.pe.f){

#table(base.pe.f$BANCARIZADOS)
#table(base.pe.f$ANTIGUEDAD_3)
#table(base.pe.f$GB)

base.pe.f$pobval <- ifelse(base.pe.f$validacion==1,1,
                           0)
table(base.pe.f$pobval)

base.pe.f$score <- ifelse(base.pe.f$pobval==1 ,
                          base.pe.f$SCORE,  0)



####################################################
######### SEGMENTACION #############################
####################################################


# table(base.pe.f$SEGMENTACION)

# Se debe asignar un tipo factor a la segmentacion ##########################
## Si no hay segmentos se ingresa 1 con label Todos #########################

# Si fuera un segmento ###
#segf <- c("Todos")

#segf <- c("Clean","Dirty")

## SIN SON MAS SE DEBE AGREGAR MAS SEGMENTOS  ###############################

# Si fuera un segmento ######################################################

#if(length(unique(base.pe.f$SEGMENTO))==1
#base.pe.f$Segmentos <- 1

## MODIFICAR SEGUN LOS SEGMENTOS #############################################
k<-1
segf<-c(1)
for (i in unique(base.pe.f$SEGMENTO)){

  base.pe.f$Segmentos <- ifelse(base.pe.f$SEGMENTO==i,k,2)
  
  segf[k]<-i

k <-k+1
  }
### SI FUERAN MAS SEGMENTOS SE DEBE AÑADIR Y CREAR LA VARIABLE #########


base.pe.f$Segmentos <- factor(base.pe.f$SEGMENTO, labels = segf)

table(base.pe.f$Segmentos)

#################  IDENTIFICACION ######################################
## MODIFICAR SEGUN NOMBRE DE IDENTIFICACION ############################
########################################################################


#base.pe.f$COD_ID_SUJETO<-base.pe.f$IDENTIFICACION_A

##### FECHA DE CORTE ###################################################
#base.pe.f$FechaCorte<-base.pe.f$fec_corte


#########################################################################

#base.pe.f$SEGMENTO<-base.pe.f$Segmentos

#################  SCORE ################################################

### TODOS LOS CORTES DE SCORE VAN ANCLADOS A LA DERECHA #################

#########################################################################

## Tabla para las PD

## Cortes de la tabla total
#score_s_T<-c(999,0,0,0,0,0,0,0,0,0)

#base.pe.f$Rango_Score_T<-cut(base.pe.f$score,c(score_s_T,0),labels=(1:10))

## Colocar los cortes del Score en cada segmento.

#  score_s<-list()
#  for(j in length(unique(base.pe.f$SEGMENTO))){
#score_s[[j]] <- c(999,	0,	0,	0,	0,	0,	0,	0,	0,	0)

#}


#c(x[2:10]+1,1)
## Colocar el valor de la PD Total y por segmento ##

####################### INFORMACION PD  ###################################


# PD_T<-c(0.010,0.010,0.010,0.010,0.010,0.010,0.010,0.010,0.010,0.010)
# 
#     PD<-list()
#   for(j in length(unique(base.pe.f$SEGMENTO))){
#   PD[[j]] <- c(0.010,0.010,0.010,0.010,0.010,0.010,0.010,0.010,0.010,0.010)
#   }




#base.pe.f$SEGMENTO <- base.pe.f$NODO_PRO
#base.pe.f$FechaCorte<- base.pe.f$FEC
##base.pe.f$COD_ID_SUJETO<-base.pe.f$IDENTIFICACION.6

base.pe.f$marcast<-ifelse(!is.na(base.pe.f$SAL_CAST_N0),"Castigado","No Castigado")

## Ingresar el tipo de credito
base.pe.f$tip_cred <- "N"

## incluir todos los filtros para obtener la población objetivo
### LLEVAR IMPRESO  PRESENTACION TABLA ########



################# EJECUTAR ################################################


#### Ragos de Score 

# if(!exists("rscores")){
#   a<-list()
#   for(i in unique(as.numeric(base.pe.f$Segmentos))){
#     a[[i]]<-base.pe.f[as.numeric(base.pe.f$Segmentos)==i,c("COD_ID_SUJETO","Segmentos","score","FechaCorte")]
#     a[[i]]$Rango_Score<-cut(a[[i]]$score,c(score_s[[i]],0),labels=(1:10))
#   }
#   rscores<-rbindlist(a)
#   rm(a)
#   base.pe.f<-merge(base.pe.f,rscores,by=c("COD_ID_SUJETO","Segmentos","score","FechaCorte"))
#   
# }


## Calificacion segun los dias

base.pe.f$calif <-"A"

base.pe.f$calif<- ifelse(base.pe.f$tip_cred=="N"|base.pe.f$tip_cred=="M"|
                           base.pe.f$tip_cred=="TC",
                         as.character(cut(base.pe.f$ndven_n,c(-1,5,20,35,50,65,80,95,125,999999),
                                          labels = c("A1","A2","A3","B1","B2","C1","C2","D","E"))),
                         base.pe.f$calif)

base.pe.f$calif<- ifelse(base.pe.f$tip_cred=="V",
                         as.character(cut(base.pe.f$ndven_n,c(-1,5,35,65,120,180,210,270,450,999999999),
                                          labels = c("A1","A2","A3","B1","B2","C1","C2","D","E"))),
                         base.pe.f$calif)

base.pe.f$calif<- ifelse(base.pe.f$tip_cred=="C",
                         as.character( cut(base.pe.f$ndven_n,c(-1,5,20,35,65,95,125,180,360,999999999),
                                           labels = c("A1","A2","A3","B1","B2","C1","C2","D","E"))),
                         base.pe.f$calif)

#View(base.pe.f[,c("COD_ID_SUJETO","ndven_n","calif")])

## Provision minima SB 
# if(!exists("por_prov_sb")){
#   por_prov_sb <- data.frame(calif = c("A1","A2","A3","B1","B2","C1","C2","D","E"), 
#                             por_prov_min=c(0.01,0.02,0.03,0.06,0.1,0.2,0.4,0.6,1),
#                             por_prov_max=c(0.01,0.02,0.05,0.09,0.19,0.39,0.59,0.99,1))
# }
# 
# ## Provision SEPS
# if(!exists("por_prov_seps")){
#   por_prov_seps <- data.frame(calif = c("A1","A2","A3","B1","B2","C1","C2","D","E"), 
#                               por_prov_min=c(0.005,0.02,0.03,0.06,0.1,0.2,0.4,0.6,1),
#                               por_prov_max=c(0.0199,0.0299,0.0599,0.0999,0.1999,0.3999,0.5999,0.9999,1))
# }

####Días vencidos

base.pe.f$Dias_mora <- as.integer(cut(base.pe.f$ndven_n, c(-1,0,30,60,90,120,max(base.pe.f$ndven_n))))
# View(base.pe.f[,c("COD_ID_SUJETO","ndven_n","Dias_mora")])



base.pe.f$marcaven<- ifelse(rowSums(base.pe.f[,c("SAL_VENCIDO_N0" ,"SAL_DEMA_N0",
                                                 "SAL_CAST_N0")],na.rm = T)>0,
                            1,0)

base.pe.f$Saldo_Mora_N0 <- rowSums(base.pe.f[,c("SAL_VENCIDO_N0" ,"SAL_DEMA_N0")],na.rm = T)
base.pe.f$Saldo_Mora_N1 <- rowSums(base.pe.f[,c("SAL_VENCIDO_N1" ,"SAL_DEMA_N1")],na.rm = T)
base.pe.f$Saldo_Mora_N2 <- rowSums(base.pe.f[,c("SAL_VENCIDO_N2" ,"SAL_DEMA_N2")],na.rm = T)
base.pe.f$Saldo_Mora_N3 <- rowSums(base.pe.f[,c("SAL_VENCIDO_N3" ,"SAL_DEMA_N3")],na.rm = T)
base.pe.f$Saldo_Mora_N4 <- rowSums(base.pe.f[,c("SAL_VENCIDO_N4" ,"SAL_DEMA_N4")],na.rm = T)
base.pe.f$Saldo_Mora_N5 <- rowSums(base.pe.f[,c("SAL_VENCIDO_N5" ,"SAL_DEMA_N5")],na.rm = T)
base.pe.f$Saldo_Mora_N6 <- rowSums(base.pe.f[,c("SAL_VENCIDO_N6" ,"SAL_DEMA_N6")],na.rm = T)
base.pe.f$Saldo_Mora_N7 <- rowSums(base.pe.f[,c("SAL_VENCIDO_N7" ,"SAL_DEMA_N7")],na.rm = T)
base.pe.f$Saldo_Mora_N8 <- rowSums(base.pe.f[,c("SAL_VENCIDO_N8" ,"SAL_DEMA_N8")],na.rm = T)
base.pe.f$Saldo_Mora_N9 <- rowSums(base.pe.f[,c("SAL_VENCIDO_N9" ,"SAL_DEMA_N9")],na.rm = T)
base.pe.f$Saldo_Mora_N10 <- rowSums(base.pe.f[,c("SAL_VENCIDO_N10" ,"SAL_DEMA_N10")],na.rm = T)
base.pe.f$Saldo_Mora_N11 <- rowSums(base.pe.f[,c("SAL_VENCIDO_N11" ,"SAL_DEMA_N11")],na.rm = T)
base.pe.f$Saldo_Mora_N12 <- rowSums(base.pe.f[,c("SAL_VENCIDO_N12" ,"SAL_DEMA_N12")],na.rm = T)

base.pe.f$EXPO <- rowSums(base.pe.f[,c("SAL_XVENCER_N0","SAL_NDI_N0","SAL_VENCIDO_N0" ,"SAL_DEMA_N0")],na.rm = T)


return(base.pe.f)

}


load("baseTRTodos.Rdata")
TRb_T <- cbind(data.frame(Score_min=c(10:1), 
                          Score_max = c(10:1), 
                          PD=0),finalDF[,4:11])

load("Base.Rdata")
TRb_T2 <- cbind(data.frame(Score_min=c(10:1), 
                          Score_max = c(10:1), 
                          PD=0),finalDF2[,4:11])

tasas2 <- function(base.pe.f,finalDF){
TRb<-list()
  k<-1
  segf<-c(1)
  for (i in unique(base.pe.f$Segmentos)){

        TRb[[i]] <- cbind(data.frame(Score_min=c(10:1), 
                                 Score_max = c(10:1), 
                                 PD=0),finalDF[,4:9],data.frame(Segmentos=k,Rango_Score=10:1))
    segf[k]<-i
    
    k <-k+1
    
      }
  TRba<-rbindlist(TRb)
  TRba$Segmentos <- factor(TRba$Segmentos,
                           labels = segf)
  rm(TRb)
return(TRba)
  }


if(!exists("por_prov_sb")){
  por_prov_sb <- data.frame(calif = c("A1","A2","A3","B1","B2","C1","C2","D","E"), 
                            por_prov_min=c(0.01,0.02,0.03,0.06,0.1,0.2,0.4,0.6,1),
                            por_prov_max=c(0.01,0.02,0.05,0.09,0.19,0.39,0.59,0.99,1))
}

## Provision SEPS
if(!exists("por_prov_seps")){
  por_prov_seps <- data.frame(calif = c("A1","A2","A3","B1","B2","C1","C2","D","E"), 
                              por_prov_min=c(0.005,0.02,0.03,0.06,0.1,0.2,0.4,0.6,1),
                              por_prov_max=c(0.0199,0.0299,0.0599,0.0999,0.1999,0.3999,0.5999,0.9999,1))
}
#View(base.pe.f[,c(1:12,104:117)])
#z<-list()
#if(!exists("TR")){
#z<-list()
#for(i in c(4,8,9,10,11,12)){
#y<- paste("ELty/TR",i,".Rdata",sep="")

#  load(y)
#  z[[i]]<-TR

#}
#        TR<-rbindlist(z)
#}

#### Funcion que obtiene las tasas de recuperacion #####


recup<-function(evsald,n){
  evsald$Recuperacion <- 0
  evsald$Recuperacion2 <- 0
  #i<-2
  for (i in 1:length(evsald$Saldos)){
    evsald$Recuperacion[i] <- round(((evsald$Suma[1] - evsald$Suma[i])/evsald$Suma[1])*100,6)
    
  }
  
  for (i in 1:length(evsald$Saldos)){
    evsald$Recuperacion2[i] <- round(((evsald$Suma[n]-evsald$Suma[i])/evsald$Suma[n])*100,6)
    
  }
  
  evsald$Recuperacion <- ifelse(evsald$Recuperacion>=100,0,evsald$Recuperacion)
  evsald$Recuperacion2 <- ifelse(evsald$Recuperacion2>=100 | evsald$Recuperacion2<0,
                                 0,evsald$Recuperacion2)
  
  return(evsald)
}


tasas<-function(m){
  z<-list()
  for(i in unique(m)){
    path<- paste0("TR",i,".Rdata")
    print(i)
    load(path)
    z[[i]]<-TR
    
  }
  TR<-rbindlist(z)
  rm(z)
  return(TR)
}



#########################  plots #############################################

Chart_box <- function(base, variable ,...) {
  # 2018-04-13: Draw the segment where occurs the max separation
  
  names(base) <- c("ID","var","Segmentos")
  
  p1<-plot_ly(base, 
              y = ~var, color = ~Segmentos,colors=brewer.pal(6, "Paired")
              , type = "box") 
  
  p2<- plot_ly(base, y = ~var,  type = "box",name="Total")
  
  p <- subplot(p1, p2,shareY = T, widths = c(0.8, 0.2)) %>%
    layout(
      title = variable ,
      yaxis = list(
      title = variable,
  #   range = c(0,1000),
      zeroline = T)
    )
  #p <- p + geom_segment(aes(x = x, y = y), colour = grey(.6), size = 1.0)
  p
}



Chart_barg <- function(base, variable,tip ,ori,...) {
  # 2018-04-13: Draw the segment where occurs the max separation
  
  names(base) <- c("ID","var","Segmentos")
  
  base$count<-1
  
  civil<- aggregate(count ~ Segmentos+var,base,sum,na.rm = T)
  civil$value<- 100*civil$count/sum(civil$count,na.rm = T)
  civil2<- aggregate(count ~ var,base,sum,na.rm = T)
  civil2$value<- 100*civil2$count/sum(civil2$count,na.rm = T)
  civil4<- aggregate(count ~ Segmentos,base,sum,na.rm = T)
  civil3<-merge(civil,civil4,by="Segmentos")
  civil3$value<-100*civil3$count.x/civil3$count.y
  civil2$Segmentos<-factor("Total")
  
  civil3<-civil3[order(civil3$value),]
  civil3$Estado<- factor(c,labels=civil3$var)
  civil2<-civil2[order(civil2$value),]
  civil2$Estado<- factor(1:length(civil2$var),labels=civil2$var)
  
  civil6<- merge(civil3,civil2[,c("var","Estado")],by="var")
  
  
  p1<- plot_ly(civil6, x = ~Segmentos, y = ~value, type = 'bar',orientation = ori, 
               name = ~Estado, color = ~Estado, colors="Paired") %>%
    layout(yaxis = list(title = ''), barmode = tip
    )
  
  p2<-plot_ly(civil2, x=~Segmentos, y = ~value, type = "bar",orientation = ori,
              color = ~Estado, colors="Paired") %>%
    layout( barmode = tip,legend = list(orientation = 'h'))
  
  p <- subplot( style(p1, showlegend = F),
           style(p2, showlegend = T),shareY = T,nrows = 2, heights = c(0.8, 0.2))
  
  p
}



# Chart_barpro <- function(base, variable,tip ,ori,...) {
#   # 2018-04-13: Draw the segment where occurs the max separation
#   
#   names(base) <- c("ID","var","Segmentos")
#   
#   base$count<-1
#   
#   civil<- aggregate(count ~ Segmentos+ProvinciaTSE,datos2,sum,na.rm = T)
#   civil$value<- 100*civil$count/sum(civil$count,na.rm = T)
#   civil2<- aggregate(count ~ ProvinciaTSE,datos2,sum,na.rm = T)
#   civil2$value<- 100*civil2$count/sum(civil2$count,na.rm = T)
#   civil4<- aggregate(count ~ Segmentos,datos2,sum,na.rm = T)
#   civil3<-merge(civil,civil4,by="Segmentos")
#   civil3$value<-100*civil3$count.x/civil3$count.y
#   civil2$Segmentos<-factor("Total")
#   
#   names(civil3)
#   civil3<-civil3[,c("ProvinciaTSE","count.y" ,"value","Segmentos")]
#   names(civil3)<-c("ProvinciaTSE","count" ,"value","Segmentos")
#   
#   civil5<-rbind(civil3,civil2)
#   
#   civil5<-civil5[civil5$Provincia!='EE.UU CANADA' ,]
#   civil5<-civil5[civil5$Provincia!='AMERICA LATINA EL CARIBE Y AFR' ,]
#   civil5<-civil5[civil5$Provincia!='EUROPA ASIA Y OCEANIA' ,]
#   
#   names(civil5)<-c("Provincia","count" ,"value","Segmentos")
#   
#   
#   p1<- plot_ly(civil5[civil5$Segmentos=="Total",],x = ~value, y = ~reorder(Provincia, value), name = 'Todos',
#                type = 'bar', orientation = 'h',#colors = "Paired"
#                marker = list(color = 'rgba(0, 128, 128, 1.0)',
#                              line = list(color = 'rgba(0, 128, 128, 1.0)', width = 1))
#   ) %>%
#     layout(yaxis = list(showgrid = FALSE, showline = FALSE,title="",
#                         showticklabels = TRUE, domain= c(0, 0.85)),
#            xaxis = list(zeroline = FALSE, showline = FALSE,title="%", 
#                         showticklabels = TRUE, showgrid = TRUE),
#            margin = list(l = 210))
#   
#   p5<- plot_ly(civil5[civil5$Segmentos=="Best",],x = ~value, y = ~Provincia, name = 'Best',
#                type = 'bar', orientation = 'h',#colors = "Paired"
#                marker = list(color = 'rgba(135,206,250, 1.0)',
#                              line = list(color = 'rgba(135,206,250, 1.0)', width = 1))
#   ) %>%
#     layout(yaxis = list(showgrid = FALSE, showline = FALSE,title="", 
#                         showticklabels = TRUE, domain= c(0, 0.85)),
#            xaxis = list(zeroline = FALSE, showline = FALSE,title="%", 
#                         showticklabels = TRUE, showgrid = TRUE),
#            margin = list(l = 210))
#   
#   
#   
#   p2<- plot_ly(civil5[civil5$Segmentos=="Advance",],x = ~value, y = ~Provincia, name = 'Advance',
#                type = 'bar', orientation = 'h',#colors = "Paired"
#                marker = list(color = 'rgba(50, 171, 96, 100)',
#                              line = list(color = 'rgba(0, 171, 96, 1.0)', width = 1))
#   ) %>%
#     layout(yaxis = list(showgrid = FALSE, showline = FALSE,title="", 
#                         showticklabels = TRUE, domain= c(0, 0.85)),
#            xaxis = list(zeroline = FALSE, showline = FALSE,title="%", 
#                         showticklabels = TRUE, showgrid = TRUE),
#            margin = list(l = 210))
#   
#   p3<- plot_ly(civil5[civil5$Segmentos=="Grow",],x = ~value, y = ~Provincia, name = 'Grow',
#                type = 'bar', orientation = 'h',#colors = "Paired"
#                marker = list(color = 'rgba(255,105,0, 0.6)',
#                              line = list(color = 'rgba(255,105,0, 0.6)', width = 1))
#   ) %>%
#     layout(yaxis = list(showgrid = FALSE, showline = FALSE,title="", 
#                         showticklabels = TRUE, domain= c(0, 0.85)),
#            xaxis = list(zeroline = FALSE, showline = FALSE,title="%", 
#                         showticklabels = TRUE, showgrid = TRUE),
#            margin = list(l = 210))
#   
#   p6<- plot_ly(civil5[civil5$Segmentos=="Analyst",],x = ~value, y = ~Provincia, name = 'Analyst',
#                type = 'bar', orientation = 'h',#colors = "Paired"
#                marker = list(color = 'rgba(148,120,221, 1)',
#                              line = list(color = 'rgba(148,120,211, 1)', width = 1))
#   ) %>%
#     layout(yaxis = list(showgrid = FALSE, showline = FALSE,title="", 
#                         showticklabels = TRUE, domain= c(0, 0.85)),
#            xaxis = list(zeroline = FALSE, showline = FALSE,title="%", 
#                         showticklabels = TRUE, showgrid = TRUE),
#            margin = list(l = 210))
#   
#   p7<- plot_ly(civil5[civil5$Segmentos=="Risk",],x = ~value, y = ~Provincia, name = 'Risk',
#                type = 'bar', orientation = 'h', #colors = "Paired"
#                marker = list(color = 'rgba(165,42,42, 0.6)',
#                              line = list(color = 'rgba(165,42,42, 1)', width = 1))
#   ) %>%
#     layout(yaxis = list(showgrid = FALSE, showline = FALSE,title="", 
#                         showticklabels = TRUE, domain= c(0, 0.85)),
#            xaxis = list(zeroline = FALSE, showline = FALSE,title="%", 
#                         showticklabels = TRUE, showgrid = TRUE),
#            margin = list(l = 210),legend = list(orientation = 'h'))
#   
#   
#   p <- subplot(style(p1),p5,p2,p3,p6,p7,shareY = T)
#   
#   
#   p
# }

