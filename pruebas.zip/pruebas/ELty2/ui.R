require(ggplot2)
require(knitr);require(rmarkdown)
require(shiny)

# Rely on the 'WorldPhones' dataset in the datasets
# package (which generally comes preloaded).
#library(datasets)

# Define the overall UI
shinyUI(navbarPage("Perdida Esperada",
                   theme = "bootstrap.css",
                   tabPanel("Base",
                            img(src="efx.png", style="float:right; padding-right:25px"),  
                            
                            sidebarLayout(      
                              
                              sidebarPanel(
                                
                                fileInput('file1', 'Seleccione el archivo txt - delimitado por tab - con formato establecido',
                                          accept=c('text/csv', 'text/comma-separated-values,text/plain')),
                                #selectInput("segm", "Escoga un segmento:",
                                #            choices = c(unique(as.character(base.pe.f$Segmentos)),"Todos"),
                                #            selected = "Todos"),
                                
                                checkboxInput("baseTR", "Base TR trabajada", FALSE),
                                
                                uiOutput("segm"),
                                
                                numericInput("minscore","Score minimo",1),
                                numericInput("maxscore","Score maximo",200),
                                numericInput("mindias","Minimo dias de vencido",0),
                                numericInput("maxdias","Maximo dias de vencido",0),
                                numericInput("n","Ingrese el mes a ser comparado",2),
                                checkboxInput("summary", "Estadisticos", TRUE),
                                actionButton("save", "Guardar")
                                
                                
                              )
                              ,
                              mainPanel(
                                
                                rHandsontableOutput("hot"),
                                hr(),
                                verbatimTextOutput("summsald"),
                                tableOutput("evsaldos"),
                                dataTableOutput("expdias")
                                
                                
                              ))),
                   tabPanel("TR",
                            img(src="efx.png", style="float:right; padding-right:25px"),  
                            # Use a fluid Bootstrap layout
                            # fluidPage(theme = "bootstrap.css",    
                            
                            # Give the page a title
                            # titlePanel("Best Fit Directv"),
                            
                            # Generate a row with a sidebar
                            sidebarLayout(      
                              
                              # Define the sidebar with one input
                              sidebarPanel(
                                numericInput("k1", 
                                             label = h5("k1 crecimiento lento en deciles iniciales (traslado en x)"), 
                                             value = -2),
                                numericInput("k2", 
                                             label = h5("k2 expande valores superiores"), 
                                             value = 3),
                                numericInput("k3", 
                                             label = h5("k3 traslado en y"), 
                                             value = 1.02),
                                numericInput("k4", 
                                             label = h5("Parametro de cambio para la TR No vencido (Aplica para cambios considerables en la Exposicion)"), 
                                             value = 0),
                                
                                actionButton("save2", "Guardar")#,
                                
                                #        fileInput('file1', 'Escoja la base para el cálculo de las TR en txt',
                                #                 accept=c('text/txt', 
                                #                         'text/comma-separated-values,text/plain', 
                                #                        '.txt'))
                                
                              ),
                              
                              # Create a spot for the barplot
                              mainPanel(
                                #plotOutput("grap"),
                                dataTableOutput("TRtabla"),
                                plotOutput('plot1')
                                #dataTableOutput(outputId="tecpro")
                              ))),
                   
                   tabPanel("TR finales",
                            img(src="efx.png", style="float:right; padding-right:25px"),
                            sidebarLayout(
                              sidebarPanel(
                                uiOutput("segm2")
                                #selectInput("segm2", "Escoga un segmento:",
                                #            choices = unique(as.character(base.pe.f$SEGMENTO)))
                                
                              ),
                              mainPanel(
                                dataTableOutput("pescore"),
                                hr(),
                                dataTableOutput("basetrf")
                                
                                
                              ))),
                   tabPanel("Perdida Esperada",
                            img(src="efx.png", style="float:right; padding-right:25px"),
                            sidebarLayout(
                              sidebarPanel(
                                
                                #        selectInput("picture", "Ingrese la entidad Reguladora:",
                                #                   choices = c("SB","SEPS"),selected = "SEPS"),
                                
                                helpText("Ingresar la entidad reguladora"),
                                
                                radioButtons("picture", "Picture:",
                                             c("SB", "SEPS")),
                                
                                
                                actionButton("calcular","Calcular"),
                                downloadButton("downloadData", "Download"),
                                
                                hr(),
                                hr("A continuacion se debe ingresar el segmento para el grafico de las PD"),
                                uiOutput("segm3")
                                #selectInput("segm3", "Escoga un segmento para PD:",
                                #            choices = c(unique(as.character(base.pe.f$SEGMENTO)),"Todos"),
                                #            selected = "Todos")
                                
                                ),
                              mainPanel(
                                fluidRow(
                                column(3, imageOutput("image2")),
                                column(3,imageOutput("image1"))
                                
                                ),
                                dataTableOutput("basepe"),
                                plotlyOutput('plotpe',width="50%"),
                                
                                dataTableOutput("tabseg"),
                                plotlyOutput('plotseg',width="50%"),
                                hr(),
                                dataTableOutput("tabcast"),
                                plotlyOutput('plot2',width="50%"),
                                plotOutput('PDgrp2',width="50%")#,
                              ))),
                   tabPanel("Resultados",
                            img(src="efx.png", style="float:right; padding-right:25px"),
                            sidebarLayout(
                              sidebarPanel(

                                #        selectInput("picture", "Ingrese la entidad Reguladora:",
                                #                   choices = c("SB","SEPS"),selected = "SEPS"),
                                
                #  selectInput('varichar', 'Escoja una variable cualitativa',"")
                #, selectInput('varinum', 'Escoja una variable cuantitativa',"")
                                uiOutput("varichar"),
                                uiOutput("varinum")
                
                ,radioButtons("tip", label = h3("Tipo de Barras"),
                             choices = list("group" = 1, "stack" = 2), 
                             selected = 1),
                radioButtons("ori", label = h3("Orientacion"),
                              choices = list("horizontal" = 1, "vertical" = 2), 
                              selected = 1)
                                # radioButtons("siste", "Sistema:",
                                #              c("SB", "Coops2 al 5","Sicom")),
                                # 
                                # helpText("Se debe ingresar el sistema")
                                
                              ),
                              mainPanel(
                                
                                fluidRow(
                                column(6,plotlyOutput('charplot',width="100%")),
                                column(6,plotlyOutput('charbox',width="100%"))
                                ),
                                fluidRow(
                                  column(6,plotlyOutput('charpe',width="100%")),
                                  column(6,plotlyOutput('charpen',width="100%"))
                                )
                              )))
                   
) 

)

